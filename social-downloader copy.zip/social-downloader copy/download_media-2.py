#!/usr/bin/env python3
"""
Reddit / Twitter (X) media downloader
--------------------------------------
Paste in links to Reddit or Twitter/X posts, and this will download the
photos or videos in them to a "downloads" folder next to this script.

HOW TO USE (see README.md for full setup instructions):
    python3 download_media.py

Then just paste URLs one at a time. Type "done" when you're finished.

You can also pass URLs directly as arguments:
    python3 download_media.py "https://reddit.com/..." "https://x.com/..."

To check that everything is set up correctly:
    python3 download_media.py --check
"""

import importlib.util
import json
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

# ----------------------------------------------------------------------------
# Settings
# ----------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = SCRIPT_DIR / "downloads"
BROWSER_DOWNLOADS = Path.home() / "Downloads"  # where Chrome saves exported files

PAUSE_BETWEEN_LINKS = 3  # seconds; being gentle avoids Reddit/X blocking you

# Passed to gallery-dl behind the scenes (you never have to edit a config file).
GALLERY_DL_CONFIG = {
    "extractor": {
        "reddit": {"api": "rest", "sleep-request": [1.0, 3.0]},
        "twitter": {"sleep-request": [1.0, 2.0]},
    }
}

# Everything the script needs to know about each site.
#   cookie_names : exact file names it will look for next to this script
#   export_name  : file-name pattern the Chrome extension produces (looked for
#                  in this folder AND in your Downloads folder)
#   login_cookies: at least one of these must be inside the file, otherwise the
#                  cookies were probably exported while logged out
SITES = {
    "twitter": {
        "label": "Twitter/X",
        "cookie_names": ["cookies.txt", "x_cookies.txt", "twitter_cookies.txt"],
        "export_name": r"^(www\.|\.)?(x|twitter)\.com.*cookies.*\.txt$",
        "login_cookies": ["auth_token"],
    },
    "reddit": {
        "label": "Reddit",
        "cookie_names": ["reddit_cookies.txt"],
        "export_name": r"^(www\.|old\.|\.)?reddit\.com.*cookies.*\.txt$",
        "login_cookies": ["reddit_session", "token_v2"],
    },
}

# Some tools only look for one of these two domains, so we give them both.
DOMAIN_TWINS = {"x.com": "twitter.com", "twitter.com": "x.com"}

# Link "fixer" sites people often paste; they all point at x.com underneath.
TWITTER_MIRRORS = {"fxtwitter.com", "vxtwitter.com", "fixupx.com", "fixvx.com"}


# ----------------------------------------------------------------------------
# Link handling
# ----------------------------------------------------------------------------

def clean_url(text):
    """Tidy up whatever was pasted: trim spaces/quotes, add https://, fix mirrors."""
    url = text.strip().strip("\"'<>()[]")
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    parts = urlparse(url)
    if parts.netloc.lower().replace("www.", "") in TWITTER_MIRRORS:
        url = parts._replace(netloc="x.com").geturl()
    return url


def detect_site(url):
    """Return 'twitter', 'reddit', or None."""
    host = urlparse(url).netloc.lower().split(":")[0]
    for domain in ("x.com", "twitter.com"):
        if host == domain or host.endswith("." + domain):
            return "twitter"
    for domain in ("reddit.com", "redd.it"):
        if host == domain or host.endswith("." + domain):
            return "reddit"
    return None


# ----------------------------------------------------------------------------
# Cookie handling
# ----------------------------------------------------------------------------

def find_cookie_file(site):
    """Find the newest cookie file for this site (this folder or ~/Downloads)."""
    info = SITES[site]
    candidates = []

    for name in info["cookie_names"]:
        path = SCRIPT_DIR / name
        if path.is_file():
            candidates.append(path)

    pattern = re.compile(info["export_name"], re.I)
    for folder in (SCRIPT_DIR, BROWSER_DOWNLOADS):
        try:
            for path in folder.glob("*.txt"):
                if pattern.match(path.name):
                    candidates.append(path)
        except OSError:
            pass  # e.g. macOS hasn't allowed Terminal to read Downloads

    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def looks_logged_in(cookie_path, site):
    """True if the cookie file contains a login cookie for this site."""
    try:
        text = cookie_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    return any(name in text for name in SITES[site]["login_cookies"])


def prepare_cookie_file(src, dest, site):
    """
    Write a cleaned-up temporary copy of the cookie file:
      - removes the '#HttpOnly_' prefixes some parsers mistake for comments
      - for X, adds a twin of every cookie for the other domain (x.com/twitter.com)
      - makes sure the required 'Netscape' header line is present
    Your original file is never modified.
    """
    lines = src.read_text(encoding="utf-8", errors="ignore").splitlines()
    fixed = [
        line[len("#HttpOnly_"):] if line.startswith("#HttpOnly_") else line
        for line in lines
    ]

    out = list(fixed)
    if site == "twitter":
        for line in fixed:
            if not line.strip() or line.startswith("#"):
                continue
            cols = line.split("\t")
            if len(cols) < 7:
                continue
            twin = DOMAIN_TWINS.get(cols[0].lstrip("."))
            if twin:
                cols[0] = ("." if cols[0].startswith(".") else "") + twin
                out.append("\t".join(cols))

    if not out or "netscape" not in out[0].lower():
        out.insert(0, "# Netscape HTTP Cookie File")
    dest.write_text("\n".join(out) + "\n", encoding="utf-8")


# ----------------------------------------------------------------------------
# Downloading
# ----------------------------------------------------------------------------

def explain_failure(site, err):
    """Turn gallery-dl's error output into something a human can act on."""
    low = err.lower()

    if "blocked by network security" in low or "you've been blocked" in low:
        print("   ❌ Reddit blocked the request (\"blocked by network security\").")
        print("      • Export fresh Reddit cookies while logged in (README, Step 6).")
        print("      • Wait a few minutes, then try again, and paste links slowly.")
        return

    if site == "twitter" and any(w in low for w in ("unavailable", "keyerror", "authorization", "401", "403")):
        print("   ❌ X refused to show that post. Most often this means your X login")
        print("      cookies are missing or expired. Export a fresh X cookie file while")
        print("      logged in (README, Step 6). It can also mean the post was deleted,")
        print("      or belongs to a private account you don't follow.")
        return

    if site == "reddit" and any(w in low for w in ("401", "403", "forbidden", "login")):
        print("   ❌ Reddit refused the request. Export fresh Reddit cookies while logged in")
        print("      (README, Step 6). NSFW posts also need an account that has NSFW enabled.")
        return

    if "yt_dlp" in low or "youtube-dl" in low or "ytdl" in low:
        print("   ❌ A video tool is missing. Run: python3 -m pip install --upgrade yt-dlp")
        return

    if "ffmpeg" in low:
        print("   ❌ ffmpeg is missing (needed to join Reddit video + audio).")
        print("      Run: brew install ffmpeg")
        return

    print("   ❌ Download failed. Last lines of the error:")
    for line in err.strip().splitlines()[-4:]:
        print("      " + line[:160])


def download(url):
    """Download one link. Returns True on success."""
    site = detect_site(url)
    if site is None:
        print(f"\n⚠️  Skipping (not a Reddit or Twitter/X link): {url}")
        return False

    label = SITES[site]["label"]
    print(f"\n⬇️  {label}: {url}")

    cookie_src = find_cookie_file(site)
    if cookie_src is None:
        print(f"   ⚠️  No {label} cookie file found, so this will probably fail.")
        print("      See README.md, Step 6, for how to export one.")
    elif not looks_logged_in(cookie_src, site):
        print(f"   ⚠️  {cookie_src.name} doesn't look like it was exported while logged in.")
    else:
        print(f"   🍪 Using {cookie_src.name}")

    DOWNLOAD_DIR.mkdir(exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp_name:
        tmp = Path(tmp_name)
        config_file = tmp / "config.json"
        config_file.write_text(json.dumps(GALLERY_DL_CONFIG), encoding="utf-8")

        cmd = [
            sys.executable, "-m", "gallery_dl",
            "--config", str(config_file),
            "-d", str(DOWNLOAD_DIR),
        ]
        if cookie_src is not None:
            prepared = tmp / "cookies.txt"
            prepare_cookie_file(cookie_src, prepared, site)
            cmd += ["--cookies", str(prepared)]
        cmd.append(url)

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=900,
            )
        except subprocess.TimeoutExpired:
            print("   ❌ Timed out after 15 minutes.")
            return False
        except OSError as e:
            print(f"   ❌ Couldn't start gallery-dl: {e}")
            return False

    out_lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
    saved = [ln for ln in out_lines if not ln.startswith("#")]
    existing = [ln for ln in out_lines if ln.startswith("#")]
    has_error = result.returncode != 0 or "[error]" in result.stderr

    if saved:
        print(f"   ✅ Saved {len(saved)} file(s):")
        for path in saved[:5]:
            print("      📄 " + Path(path).name)
        if len(saved) > 5:
            print(f"      …and {len(saved) - 5} more")
        if has_error:
            print("   ⚠️  Some parts of that post may have failed:")
            explain_failure(site, result.stderr)
        return True

    if existing and not has_error:
        print("   ✅ Already downloaded earlier, nothing new to save.")
        return True

    if not has_error:
        print("   ⚠️  Nothing to download: that post doesn't seem to contain a photo or video.")
        return False

    explain_failure(site, result.stderr)
    return False


# ----------------------------------------------------------------------------
# Setup check
# ----------------------------------------------------------------------------

def gallery_dl_installed():
    return importlib.util.find_spec("gallery_dl") is not None


def check_setup():
    """Print a health report so problems are easy to spot."""
    print("Checking your setup...\n")
    problems = 0

    print(f"✅ Python {sys.version.split()[0]}")

    if gallery_dl_installed():
        version = subprocess.run(
            [sys.executable, "-m", "gallery_dl", "--version"],
            capture_output=True, text=True,
        ).stdout.strip()
        print(f"✅ gallery-dl {version}")
    else:
        problems += 1
        print("❌ gallery-dl is not installed.")
        print("   Fix: python3 -m pip install --upgrade gallery-dl --break-system-packages")

    if importlib.util.find_spec("yt_dlp"):
        print("✅ yt-dlp")
    else:
        problems += 1
        print("❌ yt-dlp is not installed (needed for Reddit videos).")
        print("   Fix: python3 -m pip install --upgrade yt-dlp --break-system-packages")

    if shutil.which("ffmpeg"):
        print("✅ ffmpeg")
    else:
        problems += 1
        print("❌ ffmpeg is not installed (needed for Reddit videos with sound).")
        print("   Fix: brew install ffmpeg")

    for site, info in SITES.items():
        label = info["label"]
        cookie = find_cookie_file(site)
        if cookie is None:
            problems += 1
            print(f"❌ {label} cookie file: not found (see README, Step 6)")
            continue
        age_days = int((time.time() - cookie.stat().st_mtime) / 86400)
        if not looks_logged_in(cookie, site):
            problems += 1
            print(f"❌ {label} cookie file: {cookie.name} found, but it doesn't contain a login.")
            print("   It was probably exported while logged out. Log in and export again.")
        elif age_days > 30:
            print(f"⚠️  {label} cookie file: {cookie.name} is {age_days} days old. "
                  "If downloads fail, export a fresh one.")
        else:
            print(f"✅ {label} cookie file: {cookie.name} ({age_days} days old)")

    print()
    if problems == 0:
        print("🎉 Everything looks good. Run: python3 download_media.py")
    else:
        print(f"Found {problems} thing(s) to fix (see the ❌ lines above).")


# ----------------------------------------------------------------------------
# Main loop
# ----------------------------------------------------------------------------

def process(url, stats):
    if stats["attempted"] > 0:
        time.sleep(PAUSE_BETWEEN_LINKS)
    stats["attempted"] += 1
    if download(url):
        stats["ok"] += 1
    else:
        stats["failed"].append(url)


def interactive(stats):
    print("Paste a Reddit or Twitter/X link and press Enter.")
    print("Type 'done' when you're finished.\n")
    while True:
        try:
            entry = input("Link (or 'done'): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if entry.lower() in ("done", "quit", "exit", "q"):
            break
        for piece in entry.split():  # allows several links pasted at once
            url = clean_url(piece)
            if url:
                process(url, stats)


def main():
    args = sys.argv[1:]

    if "--check" in args:
        check_setup()
        return

    if not gallery_dl_installed():
        print("❌ gallery-dl isn't installed yet. Run this first:")
        print("   python3 -m pip install --upgrade gallery-dl yt-dlp --break-system-packages")
        sys.exit(1)

    if not shutil.which("ffmpeg"):
        print("ℹ️  ffmpeg not found: Reddit videos may fail or have no sound. Fix: brew install ffmpeg")
    if importlib.util.find_spec("yt_dlp") is None:
        print("ℹ️  yt-dlp not found: Reddit videos may fail. Fix: python3 -m pip install yt-dlp --break-system-packages")

    stats = {"attempted": 0, "ok": 0, "failed": []}

    if args:
        for arg in args:
            url = clean_url(arg)
            if url:
                process(url, stats)
    else:
        interactive(stats)

    if stats["attempted"] == 0:
        print("No links given, nothing to do.")
        return

    print(f"\n🎉 Finished: {stats['ok']}/{stats['attempted']} link(s) downloaded successfully.")
    if stats["failed"]:
        print("These didn't work (you can paste them again after fixing the issue above):")
        for url in stats["failed"]:
            print("   " + url)
        print("Tip: run  python3 download_media.py --check  to see if something is misconfigured.")
    print(f"📁 Files saved in: {DOWNLOAD_DIR}")


if __name__ == "__main__":
    main()
